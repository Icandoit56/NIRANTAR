# NIRANTAR — AI Disaster Response Command Center

A Vite + React command-center style prototype for disaster intelligence, simulation, relief resources, analytics and public incident reporting.

## Run

```bash
npm install
npm run dev
```

## Included UX

- Cinematic disaster/relief imagery on every major page, with dark overlays for readability.
- Responsive command-center layout with larger, easier-to-read typography.
- Type-ahead State / UT and City / Place controls. Users can type freely; suggestions are optional and appear below the field.
- India location data with state/city suggestions and free-text place entry.
- Interactive India map with hover state intelligence, selectable states and pulsing incident markers.
- Simulation includes Flood, Earthquake, Cyclone, Landslide, Wildfire, Heatwave, Drought, Tsunami, Avalanche, Thunderstorm and Extreme Wind.
- Resource inventory cards include relief imagery.
- Analytics graph and donut chart show interactive hover tooltips with values and percentages.
- Disaster report form removes photo/video attachment and adds browser-based location auto-detection with reverse geocoding when available.

## Notes

The report location detector uses the browser Geolocation API and, when available, OpenStreetMap Nominatim reverse geocoding. Users can always type/edit the location manually.

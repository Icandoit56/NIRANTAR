import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Simulation from "./pages/Simulation";
import Resources from "./pages/Resources";
import Analytics from "./pages/Analytics";
import AboutUs from "./pages/AboutUs";
import ReportDisaster from "./pages/ReportDisaster";

export default function App() {
  return (
    <BrowserRouter>
      <div className="app-shell">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/simulation" element={<Simulation />} />
            <Route path="/resources" element={<Resources />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/about" element={<AboutUs />} />
            <Route path="/report" element={<ReportDisaster />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}

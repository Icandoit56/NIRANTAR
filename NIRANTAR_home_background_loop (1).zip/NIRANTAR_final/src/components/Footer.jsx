import React from "react";
import { Link } from "react-router-dom";
import { ShieldCheck, Linkedin, Instagram, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-grid">
        <div className="footer-brand">
          <Link to="/" className="brand">
            <span className="brand-icon"><ShieldCheck size={25}/></span>
            <span><b>NIRANTAR</b><small>RESILIENT TOGETHER</small></span>
          </Link>
          <p>An AI-powered disaster response and supply chain command center built for a safer, stronger India.</p>
        </div>
        <div>
          <h4>Platform</h4>
          <Link to="/dashboard">Dashboard</Link><Link to="/simulation">Simulation</Link>
          <Link to="/resources">Resources</Link><Link to="/analytics">Analytics</Link>
        </div>
        <div>
          <h4>Company</h4>
          <Link to="/about">About Us</Link><a href="#mission">Our Mission</a><a href="#careers">Careers</a>
        </div>
        <div>
          <h4>Support</h4>
          <a href="mailto:support@nirantar.example">Help Center</a>
          <a href="mailto:support@nirantar.example">Contact Us</a>
          <Link to="/report">Report Issue</Link>
          <a href="#privacy">Privacy Policy</a>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© 2026 NIRANTAR. All rights reserved.</span>
        <div className="socials"><span>Stay Connected</span><a href="#linkedin"><Linkedin size={16}/></a><a href="#instagram"><Instagram size={16}/></a><a href="mailto:support@nirantar.example"><Mail size={16}/></a></div>
      </div>
    </footer>
  );
}

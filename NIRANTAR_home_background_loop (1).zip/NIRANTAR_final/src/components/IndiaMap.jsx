import React, { memo, useState } from "react";
import { ComposableMap, Geographies, Geography, Marker } from "react-simple-maps";

// Published India state/UT TopoJSON. Keeping the real geometry here avoids a hand-drawn map.
const INDIA_TOPO =
  "https://raw.githubusercontent.com/udit-001/india-maps-data/main/topojson/india.json";

const STATE_ALERTS = {
  Assam: { level: "critical", value: "CRITICAL", details: "Flood risk · Dibrugarh" },
  Kerala: { level: "high", value: "HIGH", details: "Flood / landslide watch" },
  "Himachal Pradesh": { level: "high", value: "HIGH", details: "Cloudburst watch · Kullu" },
  Bihar: { level: "moderate", value: "MODERATE", details: "Flood preparedness" },
  Odisha: { level: "moderate", value: "MODERATE", details: "Cyclone watch · Puri" },
  Gujarat: { level: "moderate", value: "MODERATE", details: "Heat / flood watch" },
  "West Bengal": { level: "high", value: "HIGH", details: "Flood / cyclone watch" },
  Maharashtra: { level: "low", value: "LOW", details: "Monitoring" },
  "Tamil Nadu": { level: "moderate", value: "MODERATE", details: "Heat / storm watch" },
  Karnataka: { level: "clear", value: "CLEAR", details: "No active major alert" },
  "Uttar Pradesh": { level: "low", value: "LOW", details: "Monitoring" },
  Rajasthan: { level: "low", value: "LOW", details: "Heat monitoring" },
  "Andhra Pradesh": { level: "low", value: "LOW", details: "Monitoring" },
  "Madhya Pradesh": { level: "clear", value: "CLEAR", details: "No active major alert" },
};

const MARKERS = [
  ["Assam", [92.9, 26.2], "critical"],
  ["Kerala", [76.3, 10.5], "high"],
  ["Himachal Pradesh", [77.2, 31.9], "high"],
  ["Bihar", [85.3, 25.5], "moderate"],
  ["Odisha", [85.1, 20.3], "moderate"],
  ["Gujarat", [71.7, 22.3], "moderate"],
  ["Maharashtra", [75.7, 19.6], "low"],
  ["Tamil Nadu", [78.6, 11.1], "moderate"],
  ["West Bengal", [87.9, 23.2], "high"],
  ["Uttar Pradesh", [80.9, 26.8], "low"],
  ["Rajasthan", [74.2, 26.9], "low"],
  ["Karnataka", [76.2, 14.9], "clear"],
  ["Andhra Pradesh", [79.5, 15.5], "low"],
  ["Madhya Pradesh", [78.6, 23.5], "clear"],
];

const COLORS = {
  critical: "#ff3f5f",
  high: "#fb923c",
  moderate: "#facc15",
  low: "#22d3ee",
  clear: "#10b981",
};

function normalize(name = "") {
  return name
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/\s+/g, " ")
    .trim();
}

function getStateName(geo) {
  const p = geo?.properties || {};
  return p.st_nm || p.ST_NM || p.NAME_1 || p.name || p.State || p.state_name || "India";
}

function getAlert(name) {
  const exact = STATE_ALERTS[name];
  if (exact) return exact;
  const key = normalize(name);
  const found = Object.entries(STATE_ALERTS).find(([state]) => normalize(state) === key);
  return found?.[1] || { level: "clear", value: "CLEAR", details: "No active major alert" };
}

function IndiaMap({ height = 500, showMarkers = true }) {
  const [hovered, setHovered] = useState(null);
  const [selected, setSelected] = useState("Assam");

  return (
    <div className="real-map-wrap" style={{ height }}>
      <ComposableMap
        projection="geoMercator"
        projectionConfig={{ scale: 910, center: [82, 22.8] }}
        width={700}
        height={height}
        className="real-india-map"
      >
        <defs>
          <filter id="india-map-glow">
            <feGaussianBlur stdDeviation="2.5" result="blur" />
            <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
        </defs>
        <Geographies geography={INDIA_TOPO}>
          {({ geographies }) => geographies.map((geo) => {
            const name = getStateName(geo);
            const alert = getAlert(name);
            const active = selected && normalize(selected) === normalize(name);
            return (
              <Geography
                key={geo.rsmKey}
                geography={geo}
                onMouseEnter={() => setHovered({ name, ...alert })}
                onMouseLeave={() => setHovered(null)}
                onClick={() => setSelected(name)}
                style={{
                  default: {
                    fill: active ? "#0d4b4d" : "#082b30",
                    stroke: "#267a76",
                    strokeWidth: 0.65,
                    outline: "none",
                  },
                  hover: {
                    fill: alert.level === "critical" ? "#401b28" : "#104447",
                    stroke: "#54eadb",
                    strokeWidth: 1.1,
                    outline: "none",
                    cursor: "pointer",
                  },
                  pressed: {
                    fill: "#155e60",
                    stroke: "#73fff1",
                    strokeWidth: 1,
                    outline: "none",
                  },
                }}
              />
            );
          })}
        </Geographies>

        {showMarkers && MARKERS.map(([name, coordinates, level]) => (
          <Marker key={name} coordinates={coordinates}>
            <g
              className="map-marker"
              onClick={() => setSelected(name)}
              onMouseEnter={() => setHovered({ name, ...getAlert(name) })}
              onMouseLeave={() => setHovered(null)}
              style={{ cursor: "pointer" }}
            >
              <circle r="7" fill="none" stroke={COLORS[level]} strokeWidth="1.5" opacity=".8" className="pulse-ring" />
              <circle r="4" fill={COLORS[level]} stroke="#031014" strokeWidth="1.4" filter="url(#india-map-glow)" />
              <circle r="1.5" fill="#fff" />
            </g>
          </Marker>
        ))}
      </ComposableMap>

      <div className="map-state-tooltip" aria-live="polite">
        <span className={`tooltip-dot ${hovered?.level || getAlert(selected).level}`} />
        <div>
          <b>{hovered?.name || selected}</b>
          <small>{hovered?.details || getAlert(selected).details}</small>
        </div>
        <strong className={hovered?.level || getAlert(selected).level}>
          {hovered?.value || getAlert(selected).value}
        </strong>
      </div>

      <div className="map-caption">Click a state · Hover for live alert details</div>
    </div>
  );
}

export default memo(IndiaMap);

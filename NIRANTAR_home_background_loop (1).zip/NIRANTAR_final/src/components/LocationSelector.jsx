import React, { useEffect, useMemo, useRef, useState } from "react";
import { Check, ChevronDown, MapPin, Search } from "lucide-react";
import { ALL_CITIES, INDIA_LOCATIONS, INDIAN_STATES } from "../data/indiaLocations";

function ComboBox({ label, value, onChange, options, placeholder, allowAll = false, disabled = false }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState(value || "");
  const ref = useRef(null);

  useEffect(() => setQuery(value || ""), [value]);
  useEffect(() => {
    const close = (event) => { if (!ref.current?.contains(event.target)) setOpen(false); };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return options.filter((item) => !q || item.toLowerCase().includes(q)).slice(0, q ? 12 : 60);
  }, [options, query]);

  const selectValue = (item) => {
    setQuery(item);
    onChange(item);
    setOpen(false);
  };

  return (
    <div className={`combo-field ${disabled ? "disabled" : ""}`} ref={ref}>
      <span className="combo-label"><MapPin size={13} /> {label}</span>
      <div className="combo-input-wrap">
        <Search size={14} className="combo-search" />
        <input
          value={query}
          disabled={disabled}
          placeholder={placeholder}
          autoComplete="off"
          onFocus={() => !disabled && setOpen(true)}
          onChange={(e) => { setQuery(e.target.value); onChange(e.target.value); setOpen(true); }}
          onKeyDown={(e) => {
            if (e.key === "Escape") setOpen(false);
            if (e.key === "Enter" && filtered[0]) selectValue(filtered[0]);
          }}
          aria-expanded={open}
          aria-autocomplete="list"
        />
        <ChevronDown size={16} className={`combo-chevron ${open ? "open" : ""}`} onClick={() => !disabled && setOpen(v => !v)} />
      </div>
      {open && !disabled && (
        <div className="combo-menu">
          {filtered.map((item) => (
            <button type="button" className="combo-option" key={item} onMouseDown={(e) => e.preventDefault()} onClick={() => selectValue(item)}>
              <span>{item}</span>{item === value && <Check size={13}/>} 
            </button>
          ))}
          {!filtered.length && <div className="combo-empty">No suggestion — press Enter to use “{query}”</div>}
          {!!query && filtered.length > 0 && <div className="combo-hint">Type any Indian place name · suggestions are optional</div>}
        </div>
      )}
    </div>
  );
}

export default function LocationSelector({ state, city, onStateChange, onCityChange, includeAll = false, className = "" }) {
  const cityOptions = state && state !== "All India" && INDIA_LOCATIONS[state]
    ? INDIA_LOCATIONS[state]
    : ALL_CITIES;

  const handleState = (next) => {
    onStateChange(next);
    if (next === "All India") onCityChange("All Cities");
    else if (next && INDIA_LOCATIONS[next] && !INDIA_LOCATIONS[next].includes(city)) onCityChange("All Cities");
  };

  return (
    <div className={`location-selector ${className}`}>
      <ComboBox
        label="State / UT"
        value={state}
        onChange={handleState}
        options={includeAll ? ["All India", ...INDIAN_STATES] : INDIAN_STATES}
        placeholder="Type a state or UT..."
        allowAll={includeAll}
      />
      <ComboBox
        label="City / Place"
        value={city}
        onChange={onCityChange}
        options={["All Cities", ...cityOptions.filter(c => c !== "All Cities")]}
        placeholder={state && state !== "All India" ? `Type a city in ${state}...` : "Type any Indian city or place..."}
        allowAll
        disabled={false}
      />
    </div>
  );
}

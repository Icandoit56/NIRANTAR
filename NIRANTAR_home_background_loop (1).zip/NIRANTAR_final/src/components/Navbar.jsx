import React, { useState } from "react";
import { NavLink, Link } from "react-router-dom";
import { ShieldCheck, Menu, X, Siren } from "lucide-react";

const links = [
  ["/", "Home"], ["/dashboard", "Dashboard"], ["/simulation", "Simulation"],
  ["/resources", "Resources"], ["/analytics", "Analytics"], ["/about", "About Us"]
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="navbar">
      <div className="nav-inner">
        <Link to="/" className="brand" onClick={() => setOpen(false)}>
          <span className="brand-icon"><ShieldCheck size={27}/></span>
          <span><b>NIRANTAR</b><small>RESILIENT TOGETHER</small></span>
        </Link>

        <nav className="desktop-nav">
          {links.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === "/"} className={({isActive}) => isActive ? "nav-link active" : "nav-link"}>
              {label}
            </NavLink>
          ))}
        </nav>

        <Link className="report-btn desktop-report" to="/report">
          <Siren size={16}/> Report Disaster
        </Link>

        <button className="mobile-menu" onClick={() => setOpen(v => !v)} aria-label="Menu">
          {open ? <X/> : <Menu/>}
        </button>
      </div>

      {open && (
        <div className="mobile-nav">
          {links.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === "/"} onClick={() => setOpen(false)}
              className={({isActive}) => isActive ? "mobile-link active" : "mobile-link"}>
              {label}
            </NavLink>
          ))}
          <Link className="report-btn" to="/report" onClick={() => setOpen(false)}>
            <Siren size={16}/> Report Disaster
          </Link>
        </div>
      )}
    </header>
  );
}

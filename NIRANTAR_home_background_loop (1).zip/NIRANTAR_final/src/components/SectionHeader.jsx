import React from "react";

export default function SectionHeader({ eyebrow, title, subtitle, center = false, action = null }) {
  return (
    <div className={`page-heading ${center ? "center" : ""}`}>
      <div className="heading-eyebrow"><span />{eyebrow}</div>
      <div className="heading-main-row">
        <div>
          <h1>{title}</h1>
          {subtitle && <p>{subtitle}</p>}
        </div>
        {action}
      </div>
    </div>
  );
}

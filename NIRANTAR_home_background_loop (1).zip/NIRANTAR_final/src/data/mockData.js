export const STATS = [
  { label: "Active Disasters", value: "12", sub: "Across India" },
  { label: "People Affected", value: "50K+", sub: "Currently" },
  { label: "Resource Units", value: "1.2K", sub: "Deployed" },
  { label: "Response Efficiency", value: "98%", sub: "AI-Optimized" }
];

export const ACTIVE_ALERTS = [
  { id: "a1", title: "Assam Floods", location: "Dibrugarh, Assam", severity: "CRITICAL", ago: "10 min ago" },
  { id: "a2", title: "Himachal Cloudburst", location: "Kullu, HP", severity: "HIGH", ago: "25 min ago" },
  { id: "a3", title: "Cyclone Alert", location: "Puri, Odisha", severity: "HIGH", ago: "1 hr ago" },
  { id: "a4", title: "Chennai Heatwave", location: "Chennai, TN", severity: "MODERATE", ago: "2 hr ago" }
];

export const TOP_AFFECTED_STATES = [
  ["Assam", "Critical"], ["Kerala", "High"], ["Himachal Pradesh", "High"],
  ["Bihar", "Moderate"], ["Odisha", "Moderate"]
];

export const RESOURCES = [
  ["Emergency Food Packets", "Food", "12,500", "Delhi Warehouse", "Available"],
  ["Medical Kits", "Medical", "3,400", "Mumbai Depot", "Available"],
  ["Water Bottles (1L)", "Water", "45,000", "Kolkata Hub", "Available"],
  ["Tents & Shelters", "Shelter", "890", "Bengaluru Depot", "Low"],
  ["Rescue Boats", "Vehicles", "145", "Guwahati Base", "Available"],
  ["Blankets", "Shelter", "22,000", "Hyderabad Depot", "Available"],
  ["Generators", "Power", "78", "Chennai Hub", "Low"],
  ["Communication Radios", "Comms", "340", "Delhi Warehouse", "Available"]
];

export const MONTHLY = [
  ["Jan", 8, 12000], ["Feb", 6, 9500], ["Mar", 10, 21000], ["Apr", 14, 34000],
  ["May", 18, 45000], ["Jun", 22, 61000], ["Jul", 28, 78000], ["Aug", 24, 65000],
  ["Sep", 16, 42000], ["Oct", 12, 28000], ["Nov", 9, 18000], ["Dec", 7, 14000]
];

export const TEAMS = [
  ["NDRF Team Alpha", "Delhi", 45, "Deployed"],
  ["NDRF Team Bravo", "Mumbai", 40, "Standby"],
  ["SDRF Assam", "Guwahati", 32, "Deployed"],
  ["Coast Guard Unit", "Chennai", 28, "Standby"],
  ["Medical Response Team", "Bengaluru", 22, "Available"],
  ["Search & Rescue K9", "Kolkata", 15, "Available"]
];

import React, { useMemo, useState } from "react";
import { Activity, AlertTriangle, ArrowUpRight, Bell, Filter, Package, RefreshCw, Users } from "lucide-react";
import { ACTIVE_ALERTS, STATS, TOP_AFFECTED_STATES } from "../data/mockData";
import IndiaMap from "../components/IndiaMap";
import Card from "../components/Card";
import SectionHeader from "../components/SectionHeader";
import LocationSelector from "../components/LocationSelector";

const statIcons = [AlertTriangle, Users, Package, Activity];
const disasterTypes = ["All Types", "Flood", "Earthquake", "Cyclone", "Landslide", "Wildfire", "Heatwave"];

export default function Dashboard() {
  const [filter, setFilter] = useState("ALL");
  const [query, setQuery] = useState("");
  const [type, setType] = useState("All Types");
  const [state, setState] = useState("All India");
  const [city, setCity] = useState("All Cities");
  const alerts = useMemo(() => ACTIVE_ALERTS.filter((a) => {
    const matchesFilter = filter === "ALL" || a.severity === filter;
    const matchesType = type === "All Types" || a.title.toLowerCase().includes(type.toLowerCase());
    const matchesState = state === "All India" || a.location.toLowerCase().includes(state.toLowerCase());
    const matchesCity = city === "All Cities" || !city || a.location.toLowerCase().includes(city.toLowerCase());
    const haystack = `${a.title} ${a.location}`.toLowerCase();
    return matchesFilter && matchesType && matchesState && matchesCity && haystack.includes(query.toLowerCase());
  }), [filter, query, type, state, city]);
  const changeState = (v) => { setState(v); setCity(v === "All India" ? "All Cities" : "All Cities"); };

  return <div className="page dashboard-page"><div className="container">
    <SectionHeader eyebrow="COMMAND CENTER" title="Operations Dashboard" subtitle="Live monitoring of disaster events, response teams and resource deployments across India." action={<div className="heading-actions"><button className="ghost-btn"><RefreshCw size={14}/> Refresh</button><button className="soft-btn"><Bell size={14}/> Subscribe Alerts</button></div>}/>

    <Card className="global-filter-card">
      <div className="filter-title"><Filter size={15}/><div><b>Intelligence Filters</b><small>Focus the command view by disaster, state and city</small></div></div>
      <div className="global-filter-grid"><label><span>Disaster Type</span><select value={type} onChange={e=>setType(e.target.value)}>{disasterTypes.map(x=><option key={x}>{x}</option>)}</select></label><LocationSelector state={state} city={city} onStateChange={changeState} onCityChange={setCity} includeAll/></div>
    </Card>

    <section className="stat-grid-four">
      {STATS.map(({ label, value, sub }, i) => { const Icon = statIcons[i]; return <Card key={label} className="metric-card"><div className={`metric-icon metric-${i}`}><Icon size={19}/></div><div><strong>{value}</strong><span>{label}</span><small>{sub}</small></div><ArrowUpRight className="metric-trend" size={15}/></Card>; })}
    </section>

    <section className="dashboard-main-grid">
      <Card className="dashboard-map-card"><div className="card-heading"><div><h3>India Situation Map</h3><p>Hover a state or incident marker for live intelligence</p></div><div className="severity-legend"><span><i className="critical"/>Critical</span><span><i className="high"/>High</span><span><i className="moderate"/>Moderate</span><span><i className="low"/>Low</span><span><i className="clear"/>Clear</span></div></div><IndiaMap height={535}/></Card>

      <Card className="alerts-panel"><div className="card-heading compact"><div><h3>Active Alerts</h3><p>{alerts.length} incidents matching current filters</p></div><Filter size={16}/></div><div className="alert-filter-row">{['ALL','CRITICAL','HIGH','MODERATE'].map(x=><button key={x} className={filter===x?'selected':''} onClick={()=>setFilter(x)}>{x}</button>)}</div><div className="alert-search"><span>⌕</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search alerts..."/></div><div className="alerts-list">{alerts.map(a=><div className="alert-item" key={a.id}><span className={`alert-icon ${a.severity.toLowerCase()}`}><AlertTriangle size={16}/></span><div><b>{a.title}</b><small>{a.location}</small><em>{a.ago} · Type: {a.title.toLowerCase().includes('flood')?'flood':a.title.toLowerCase().includes('cyclone')?'cyclone':'weather'}</em></div><strong className={a.severity.toLowerCase()}>{a.severity}</strong></div>)}{!alerts.length && <div className="empty-state">No incidents match these filters.</div>}</div></Card>
    </section>

    <section className="dashboard-bottom-grid"><Card><div className="card-heading compact"><h3>Most Affected States</h3><span className="tiny-live"><i/> LIVE</span></div>{TOP_AFFECTED_STATES.map(([s,l])=><div className="state-line" key={s}><span>{s}</span><b className={l.toLowerCase()}>{l}</b></div>)}</Card><Card className="quick-stat-card"><div className="quick-icon"><Users size={19}/></div><div><span>Response teams active</span><strong>6</strong><small>Teams tracked across the country</small></div><ArrowUpRight size={17}/></Card><Card className="quick-stat-card"><div className="quick-icon orange"><Package size={19}/></div><div><span>Resource readiness</span><strong>1.2K</strong><small>Units available or deployed</small></div><ArrowUpRight size={17}/></Card></section>
  </div></div>;
}

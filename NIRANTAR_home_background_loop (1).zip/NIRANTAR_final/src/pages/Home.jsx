import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  Activity,
  Users,
  Package,
  Gauge,
  MapPin,
  Radio,
  ShieldAlert,
  Waves,
  Mountain,
  Tornado,
} from "lucide-react";
import { STATS, ACTIVE_ALERTS, TOP_AFFECTED_STATES } from "../data/mockData";
import IndiaMap from "../components/IndiaMap";
import Card from "../components/Card";
import SectionHeader from "../components/SectionHeader";

const steps = [
  ["Detect", "Real-time monitoring detects disasters instantly", Radio],
  ["Analyze", "AI agents assess impact & predict requirements", Activity],
  ["Allocate", "Resources are allocated from best available locations", Package],
  ["Optimize", "Smart route planning ensures fastest & safest delivery", Gauge],
  ["Deliver", "Aid reaches the right place at the right time", ShieldAlert],
];

const scenarios = [
  ["Flood Response", "Assam", "Predict affected zones and optimize relief deployment.", Waves, "flood"],
  ["Earthquake Response", "Himalayan Region", "Prioritize damaged zones and coordinate emergency resources.", Mountain, "earthquake"],
  ["Cyclone Response", "East Coast", "Track storm movement and prepare evacuation routes before impact.", Tornado, "cyclone"],
];

const statIcons = [Activity, Users, Package, Gauge];

const heroImages = [
  { src: "/assets/disaster-earthquake.jpg", label: "EARTHQUAKE RESPONSE" },
  { src: "/assets/disaster-flood.webp", label: "FLOOD RESPONSE" },
  { src: "/assets/disaster-fire.webp", label: "WILDFIRE RESPONSE" },
];

export default function Home() {
  const [heroIndex, setHeroIndex] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setHeroIndex((current) => (current + 1) % heroImages.length);
    }, 6500);

    return () => window.clearInterval(timer);
  }, []);

  return (
    <main className="nirantar-home">
      {/* HERO */}
      <section className="command-hero">
        <div className="hero-slideshow" aria-hidden="true">
          {heroImages.map((image, index) => {
            const previous = (heroIndex - 1 + heroImages.length) % heroImages.length;
            const next = (heroIndex + 1) % heroImages.length;
            const position =
              index === heroIndex ? "active" :
              index === previous ? "previous" :
              index === next ? "next" : "hidden";

            return (
              <div
                className={`hero-slide ${position}`}
                key={image.src}
                style={{ backgroundImage: `url(${image.src})` }}
              />
            );
          })}
        </div>
        <div className="command-hero-overlay" />
        <div className="command-grid-overlay" />

        <div className="command-container">
          <div className="hero-status">
            <div className="hero-status-left">
              <span className="status-pulse" />
              SYSTEM OPERATIONAL
            </div>
            <div className="hero-status-right">
              <Radio size={14} />
              LIVE DISASTER INTELLIGENCE
            </div>
          </div>

          <div className="hero-layout">
            <div className="hero-content">
              <div className="hero-kicker">
                <span />
                AI-POWERED DISASTER RESPONSE
              </div>

              <h1>
                Faster decisions.
                <br />
                <span>Stronger communities.</span>
              </h1>

              <p className="hero-description">
                NIRANTAR transforms real-time disaster data into actionable
                intelligence — helping response teams predict, prioritize and
                deploy resources where they matter most.
              </p>

              <div className="hero-buttons">
                <Link to="/simulation" className="hero-primary-btn">
                  <ShieldAlert size={18} />
                  Simulate Disaster
                  <ArrowRight size={17} />
                </Link>

                <Link to="/dashboard" className="hero-secondary-btn">
                  Explore Command Center
                  <ArrowRight size={17} />
                </Link>
              </div>

              <div className="hero-trust">
                <div className="trust-line" />
                REAL-TIME • AI-ASSISTED • INDIA-WIDE
              </div>
            </div>

            <div className="hero-alert-panel">
              <div className="alert-panel-top">
                <div>
                  <span className="panel-label">PRIORITY ALERT</span>
                  <h3>Assam Floods</h3>
                </div>
                <span className="critical-badge">CRITICAL</span>
              </div>

              <div className="alert-location">
                <MapPin size={14} />
                Guwahati, Assam
              </div>

              <div className="alert-divider" />

              <div className="alert-data">
                <div>
                  <span>AFFECTED</span>
                  <strong>18,400</strong>
                </div>
                <div>
                  <span>RISK LEVEL</span>
                  <strong className="risk-red">HIGH</strong>
                </div>
                <div>
                  <span>RESPONSE</span>
                  <strong className="risk-green">ACTIVE</strong>
                </div>
              </div>

              <div className="alert-progress">
                <div className="progress-header">
                  <span>Response deployment</span>
                  <strong>82%</strong>
                </div>
                <div className="progress-track">
                  <div className="progress-fill" />
                </div>
              </div>

              <div className="alert-footer">
                <span className="mini-live-dot" />
                Updated 42 sec ago
              </div>
            </div>
          </div>
        </div>

        <div className="hero-slide-controls" aria-label="Disaster scene selector">
          <div className="hero-slide-label">{heroImages[heroIndex].label}</div>
          <div className="hero-slide-dots">
            {heroImages.map((image, index) => (
              <button
                key={image.src}
                type="button"
                aria-label={`Show ${image.label.toLowerCase()}`}
                className={index === heroIndex ? "active" : ""}
                onClick={() => setHeroIndex(index)}
              />
            ))}
          </div>
          <div className="hero-slide-count">0{heroIndex + 1} / 0{heroImages.length}</div>
        </div>

        <div className="hero-scroll">
          <span />
          SCROLL TO EXPLORE
        </div>
      </section>

      {/* STATS */}
      <section className="command-stats">
        <div className="command-container">
          <div className="stats-grid">
            {STATS.map(({ label, value, sub }, i) => {
              const Icon = statIcons[i];
              return (
                <div className="stat-card" key={label}>
                  <div className="stat-icon">
                    <Icon size={20} />
                  </div>
                  <div className="stat-content">
                    <span>{label}</span>
                    <strong>{value}</strong>
                    <small>{sub}</small>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="command-section how-section">
        <div className="command-container">
          <div className="section-heading-center">
            <span className="section-kicker">NIRANTAR INTELLIGENCE ENGINE</span>
            <h2>
              From disaster data
              <br />
              <span>to decisive action.</span>
            </h2>
            <p>
              One intelligent command layer connecting information, people and
              resources during a crisis.
            </p>
          </div>

          <div className="process-grid">
            {steps.map(([title, text, Icon], i) => (
              <div className="process-card" key={title}>
                <span className="process-number">0{i + 1}</span>
                <div className="process-line" />
                <div className="process-icon"><Icon size={17} /></div>
                <h3>{title}</h3>
                <p>{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* LIVE MAP */}
      <section className="command-section map-section">
        <div className="command-container">
          <div className="section-heading-row">
            <div>
              <span className="section-kicker">LIVE SITUATION</span>
              <h2>India at a glance.</h2>
              <p>
                Monitor active disaster zones and response activity across the
                country.
              </p>
            </div>
            <Link to="/dashboard" className="text-link">
              Open Command Center <ArrowRight size={16} />
            </Link>
          </div>

          <div className="map-command-layout">
            <div className="map-main-panel">
              <IndiaMap height={520} />
            </div>

            <div className="map-side-panel">
              <div className="map-side-block">
                <div className="side-title-row">
                  <h4>Top affected states</h4>
                  <span>LIVE</span>
                </div>
                {TOP_AFFECTED_STATES.map(([state, level]) => (
                  <div className="state-row" key={state}>
                    <span>{state}</span>
                    <b className={level.toLowerCase()}>{level}</b>
                  </div>
                ))}
              </div>

              <div className="map-side-block">
                <div className="side-title-row">
                  <h4>Recent alerts</h4>
                  <span>{ACTIVE_ALERTS.length}</span>
                </div>
                {ACTIVE_ALERTS.slice(0, 3).map((alert) => (
                  <div className="alert-row" key={alert.id}>
                    <span className={`alert-level ${alert.severity.toLowerCase()}`} />
                    <div>
                      <b>{alert.title}</b>
                      <small>{alert.location}</small>
                    </div>
                    <strong>{alert.severity}</strong>
                  </div>
                ))}
              </div>

              <Link to="/dashboard" className="map-side-link">
                View all intelligence <ArrowRight size={14} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* SCENARIOS */}
      <section className="command-section scenarios-section">
        <div className="command-container">
          <div className="section-heading-center">
            <span className="section-kicker">RESPONSE SCENARIOS</span>
            <h2>
              Built for every
              <br />
              <span>kind of crisis.</span>
            </h2>
          </div>

          <div className="scenario-grid premium-scenario-grid">
            {scenarios.map(([title, location, description, Icon, id]) => (
              <Card className={`scenario-card premium-scenario ${id}`} key={id}>
                <div className="scenario-image">
                  <div className="scenario-image-overlay" />
                  <div className="scenario-icon"><Icon size={24} /></div>
                  <span>{location}</span>
                </div>
                <div className="scenario-body">
                  <h3>{title}</h3>
                  <p>{description}</p>
                  <Link to={`/simulation?type=${id}`}>
                    Run Simulation <ArrowRight size={15} />
                  </Link>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* MISSION */}
      <section className="mission-section">
        <div className="mission-bg" />
        <div className="mission-overlay" />
        <div className="command-container mission-content">
          <span className="section-kicker">OUR MISSION</span>
          <h2>
            When every second matters,
            <br />
            <span>intelligence saves lives.</span>
          </h2>
          <p>
            NIRANTAR brings the entire disaster response ecosystem together in
            one intelligent command center.
          </p>
          <Link to="/dashboard" className="hero-primary-btn">
            Enter Command Center <ArrowRight size={17} />
          </Link>
        </div>
      </section>
    </main>
  );
}

import React, { useState } from "react";
import { AlertTriangle, CheckCircle2, MapPin, Phone, Send, Siren, Navigation, ShieldAlert, LocateFixed } from "lucide-react";
import Card from "../components/Card";
import SectionHeader from "../components/SectionHeader";
import LocationSelector from "../components/LocationSelector";

const disasters = ["Flood","Earthquake","Cyclone","Landslide","Wildfire","Heatwave","Drought","Tsunami","Avalanche","Thunderstorm","Extreme Wind"];

export default function ReportDisaster() {
  const [sent, setSent] = useState(false); const [state, setState] = useState("Assam"); const [city, setCity] = useState("Dibrugarh"); const [severity, setSeverity] = useState("High");
  const [detecting, setDetecting] = useState(false); const [detected, setDetected] = useState("");
  const autoDetect = () => {
    if (!navigator.geolocation) { setDetected("Location services are not supported by this browser."); return; }
    setDetecting(true); setDetected("Requesting your location permission…");
    navigator.geolocation.getCurrentPosition(async ({coords}) => {
      const { latitude, longitude } = coords;
      try {
        const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${latitude}&lon=${longitude}&zoom=10&accept-language=en`);
        const data = await res.json(); const a = data.address || {};
        const detectedState = a.state || a.region || ""; const detectedCity = a.city || a.town || a.village || a.municipality || "";
        setState(detectedState || "All India"); setCity(detectedCity || "All Cities");
        setDetected(detectedCity || detectedState ? `Detected: ${detectedCity ? detectedCity + ", " : ""}${detectedState}` : `Detected coordinates: ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
      } catch { setDetected(`Location detected at ${latitude.toFixed(4)}, ${longitude.toFixed(4)}. You can edit the place manually.`); }
      setDetecting(false);
    }, (error) => { setDetecting(false); setDetected(error.code === 1 ? "Location permission was denied. You can enter the place manually." : "Could not detect location. Please enter it manually."); }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 });
  };
  if (sent) return <div className="page report-page"><div className="container report-success"><div className="success-orbit"><CheckCircle2 size={48}/></div><span className="heading-eyebrow"><span/> REPORT RECEIVED</span><h1>Help is already moving.</h1><p>Your incident report has entered the verification queue. Keep your ticket ID ready for updates.</p><button className="primary-btn" onClick={()=>setSent(false)}>Submit another report</button></div></div>;

  return <div className="page report-page"><div className="container">
    <SectionHeader eyebrow="EMERGENCY" title="Report a Disaster" subtitle="Provide details of a disaster event so our response network can act quickly. Give the clearest location and risk information you can verify."/>
    <div className="report-layout"><div>
      <Card className="report-form-card"><div className="form-grid">
        <label>Disaster Type *<select><option value="">Select disaster</option>{disasters.map(x=><option key={x}>{x}</option>)}</select></label>
        <label>Severity *<select value={severity} onChange={e=>setSeverity(e.target.value)}>{['Low','Moderate','High','Critical'].map(x=><option key={x}>{x}</option>)}</select></label>
        <div className="full report-location-wrap"><LocationSelector state={state} city={city} onStateChange={v=>{setState(v);setCity("All Cities")}} onCityChange={setCity} includeAll/><div className="detect-row"><button type="button" className="detect-btn" onClick={autoDetect} disabled={detecting}><LocateFixed size={15}/> {detecting ? "Detecting…" : "Auto-detect my location"}</button><span>{detected}</span></div></div>
        <label className="full">Estimated People Affected<input inputMode="numeric" placeholder="e.g., 500"/></label>
        <label className="full">Description *<textarea rows="6" placeholder="Describe what you're seeing, ongoing risks, trapped people, damaged infrastructure, and immediate needs…"/></label>
      </div></Card>
      <Card className="contact-card"><label>Your Name *<input placeholder="Full name"/></label><label>Contact Number *<input placeholder="+91 90000 00000"/></label></Card>
      <button className="submit-report" onClick={()=>setSent(true)}><Send size={17}/> Submit Emergency Report <span>→</span></button>
    </div><aside className="report-aside">
      <Card className="danger-card"><div className="aside-title danger"><AlertTriangle size={17}/> Immediate Danger?</div><p>If life is at risk, please call emergency services first. This form is for reporting and coordinating response.</p>{[["National Emergency","112"],["Disaster Helpline (NDMA)","1078"],["Ambulance","102"]].map(([l,n])=><div className="hotline" key={n}><span>{l}</span><b>{n}</b><Phone size={15}/></div>)}</Card>
      <Card className="next-card"><h3>What happens next?</h3>{["Your report is triaged by AI","Verification team cross-checks satellite + ground data","Nearest response team is matched to the incident","You receive updates on your ticket ID"].map((x,i)=><div className="next-step" key={x}><span>{i+1}</span><p>{x}</p></div>)}</Card>
      <Card className="location-card"><Navigation size={17}/><div><b>Location Auto-Detect</b><p>Use your browser location to prefill the nearest city/state. You can always edit it.</p></div><button type="button" onClick={autoDetect} disabled={detecting}>{detecting ? "…" : "Enable"}</button></Card>
      <div className="report-note"><ShieldAlert size={15}/> Share only information you can verify. Accurate reports help responders reach people faster.</div>
    </aside></div>
  </div></div>;
}

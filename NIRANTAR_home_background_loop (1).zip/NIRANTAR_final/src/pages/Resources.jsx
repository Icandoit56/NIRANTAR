import React, { useMemo, useState } from "react";
import { CheckCircle2, Package, Search, MapPin, AlertCircle, ArrowUpRight, Boxes, Filter } from "lucide-react";
import { RESOURCES } from "../data/mockData";
import Card from "../components/Card";
import SectionHeader from "../components/SectionHeader";
import LocationSelector from "../components/LocationSelector";

const categoryImages={
  Food:"/assets/food-kit.jpg", Medical:"/assets/warehouse.jpg", Water:"/assets/warehouse.jpg",
  Shelter:"/assets/first-aid.jpg", Vehicles:"/assets/command-room.jpg", Power:"/assets/command-room.jpg", Comms:"/assets/india-intelligence.jpg"
};
const depotLocations={"Delhi Warehouse":["Delhi","New Delhi"],"Mumbai Depot":["Maharashtra","Mumbai"],"Kolkata Hub":["West Bengal","Kolkata"],"Bengaluru Depot":["Karnataka","Bengaluru"],"Guwahati Base":["Assam","Guwahati"],"Hyderabad Depot":["Telangana","Hyderabad"],"Chennai Hub":["Tamil Nadu","Chennai"]};

export default function Resources(){
 const [q,setQ]=useState(""); const [category,setCategory]=useState("All"); const [status,setStatus]=useState("All"); const [state,setState]=useState("All India"); const [city,setCity]=useState("All Cities");
 const categories=["All","Food","Medical","Water","Shelter","Vehicles","Power","Comms"];
 const rows=useMemo(()=>RESOURCES.filter(r=>{const [name,cat,,depot,stock]=r; const loc=depotLocations[depot]||[]; return name.toLowerCase().includes(q.toLowerCase())||depot.toLowerCase().includes(q.toLowerCase()) ? (category==="All"||cat===category)&&(status==="All"||stock===status)&&(state==="All India"||loc[0]===state)&&(city==="All Cities"||loc[1]===city) : false;}),[q,category,status,state,city]);
 const total=RESOURCES.reduce((n,r)=>n+Number(r[2].replace(/,/g,"")),0); const available=RESOURCES.filter(r=>r[4]==="Available").length; const low=RESOURCES.filter(r=>r[4]==="Low").length;
 const changeState=v=>{setState(v);setCity("All Cities")};
 return <div className="page resources-page"><div className="container"><SectionHeader eyebrow="SUPPLY CHAIN" title="Resource Inventory" subtitle="Track relief supplies, medical kits and equipment stored across depots nationwide."/><div className="inventory-stats"><Card><span>Total Units</span><strong>{total.toLocaleString()}</strong></Card><Card><span>Categories</span><strong>7</strong></Card><Card><span>Available</span><strong>{available}</strong></Card><Card><span>Low Stock</span><strong className="yellow">{low}</strong></Card></div>
 <Card className="resource-toolbar"><div className="resource-search"><Search size={17}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search resources, warehouses..."/></div><div className="resource-filter-row"><div className="mini-filter"><Filter size={14}/><span>Location</span></div><LocationSelector state={state} city={city} onStateChange={changeState} onCityChange={setCity} includeAll/><label className="toolbar-select"><span>Status</span><select value={status} onChange={e=>setStatus(e.target.value)}><option>All</option><option>Available</option><option>Low</option></select></label></div><div className="category-pills">{categories.map(c=><button key={c} className={category===c?'selected':''} onClick={()=>setCategory(c)}>{c}</button>)}</div></Card>
 <div className="resource-grid">{rows.map(r=><Card className="resource-card" key={r[0]}><div className="resource-image" style={categoryImages[r[1]]?{backgroundImage:`url("${categoryImages[r[1]]}")`}:undefined}>{!categoryImages[r[1]]&&<Boxes size={43}/>}<span className={`resource-status ${r[4].toLowerCase()}`}>{r[4]==="Available"?<CheckCircle2 size={12}/>:<AlertCircle size={12}/>} {r[4].toLowerCase()}</span></div><div className="resource-body"><small>{r[1].toUpperCase()}</small><h3>{r[0]}</h3><div className="resource-number"><strong>{r[2]}</strong><span>{r[1]==='Food'?'packets':r[1]==='Medical'?'kits':r[1]==='Water'?'bottles':r[1]==='Shelter'?'tents':'units'}</span></div><p><MapPin size={13}/> {r[3]}</p><button>Request Dispatch <ArrowUpRight size={14}/></button></div></Card>)}{!rows.length&&<div className="empty-state resource-empty">No resources match your selected filters.</div>}</div></div></div>;
}

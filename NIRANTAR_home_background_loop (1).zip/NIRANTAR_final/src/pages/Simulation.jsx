import React, { useEffect, useState } from "react";
import { Clock3, MapPin, Play, RotateCcw, Waves, Mountain, Tornado, Zap, Flame, CloudRain, Snowflake, Wind, Sun, Waves as TsunamiIcon } from "lucide-react";
import Card from "../components/Card";
import SectionHeader from "../components/SectionHeader";
import LocationSelector from "../components/LocationSelector";

const steps = ["Detection", "Verification", "Impact Assessment", "Resource Dispatch", "Field Deployment", "Aid Delivery"];
const types = [
  ["Flood", Waves], ["Earthquake", Mountain], ["Cyclone", Tornado], ["Landslide", Mountain],
  ["Wildfire", Flame], ["Heatwave", Sun], ["Drought", Sun], ["Tsunami", TsunamiIcon],
  ["Avalanche", Snowflake], ["Thunderstorm", CloudRain], ["Extreme Wind", Wind]
];

export default function Simulation() {
  const [type, setType] = useState("Flood"); const [state, setState] = useState("Assam"); const [city, setCity] = useState("Dibrugarh");
  const [severity, setSeverity] = useState("High"); const [running, setRunning] = useState(false); const [progress, setProgress] = useState(0); const [timeline, setTimeline] = useState(60);
  const [allocation, setAllocation] = useState({ Food: 40, Medical: 30, Water: 60, Shelter: 20 });
  useEffect(() => { if (!running) return; const t = setInterval(() => setProgress(p => { if (p >= 100) { clearInterval(t); setRunning(false); return 100; } return p + 2; }), 80); return () => clearInterval(t); }, [running]);
  const activeStep = Math.min(5, Math.floor(progress / 17));
  const changeState = (v) => { setState(v); setCity(v === "Assam" ? "Dibrugarh" : "All Cities"); };
  const setAlloc = (key, value) => setAllocation(a => ({ ...a, [key]: Number(value) }));

  return <div className="page simulation-page"><div className="container">
    <SectionHeader eyebrow="AI-POWERED" title="Disaster Response Simulation" subtitle="Configure a scenario and watch NIRANTAR's AI coordinate detection, allocation and delivery in real-time."/>
    <div className="simulation-layout">
      <Card className="simulation-controls">
        <label>Disaster Type<select value={type} onChange={e=>{setType(e.target.value);setRunning(false);setProgress(0)}}>{types.map(([x])=><option key={x}>{x}</option>)}</select></label>
        <LocationSelector state={state} city={city} onStateChange={changeState} onCityChange={setCity}/>
        <div className="control-label">Severity</div><div className="severity-buttons">{['Low','Moderate','High','Critical'].map(x=><button className={severity===x?'selected':''} key={x} onClick={()=>setSeverity(x)}>{x}</button>)}</div>
        <div className="control-label timeline-label">Timeline: {timeline} min window</div><input className="range" type="range" min="15" max="180" value={timeline} onChange={e=>setTimeline(Number(e.target.value))}/>
        <div className="allocation">{Object.entries(allocation).map(([name,val])=><React.Fragment key={name}><div><span>{name}</span><b>{val}%</b></div><input type="range" min="0" max="100" value={val} onChange={e=>setAlloc(name,e.target.value)}/></React.Fragment>)}</div>
        <div className="sim-control-actions"><button className="start-btn" onClick={()=>{setRunning(true);setProgress(0)}}><Play size={16}/> Start Simulation</button><button className="reset-square" onClick={()=>{setRunning(false);setProgress(0)}}><RotateCcw size={16}/></button></div>
      </Card>
      <div className="simulation-right"><Card className="progress-card"><div className="card-heading compact"><h3><Zap size={17}/> Simulation Progress</h3><span><Clock3 size={13}/> {Math.round(progress)}s / 100s</span></div><div className="progress-track-big"><i style={{width:`${progress}%`}}/></div><div className="sim-steps">{steps.map((s,i)=><div className={i<=activeStep && progress>0?'done':''} key={s}><span>{i+1}</span><small>{s}</small></div>)}</div><div className="scenario-summary"><div><span>TYPE</span><b>{type}</b></div><div><span>LOCATION</span><b><MapPin size={13}/> {city === "All Cities" ? state : `${city}, ${state}`}</b></div><div><span>SEVERITY</span><b>{severity}</b></div><div><span>TIMELINE</span><b>{timeline} min</b></div></div></Card><Card className="event-log"><div className="card-heading compact"><h3>Live Event Log</h3><span className="tiny-live"><i/> LIVE</span></div><div className="terminal">{running || progress===100 ? <>{progress>5&&<p>[00:01] <b>DETECT</b> — satellite signal received from {state}</p>}{progress>25&&<p>[00:14] <b>VERIFY</b> — cross-checking ground reports near {city === "All Cities" ? state : city}</p>}{progress>45&&<p>[00:28] <b>IMPACT</b> — estimating population exposure for {type}</p>}{progress>70&&<p>[00:42] <b>DISPATCH</b> — nearest resources allocated</p>}{progress>95&&<p>[00:58] <b>DEPLOY</b> — response team route optimized</p>}</> : <span>// Start the simulation to see live agent activity...</span>}</div></Card></div>
    </div>
  </div></div>;
}
